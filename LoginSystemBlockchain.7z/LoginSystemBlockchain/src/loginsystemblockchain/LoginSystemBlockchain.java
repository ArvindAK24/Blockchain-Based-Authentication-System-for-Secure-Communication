/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package loginsystemblockchain;

import javax.swing.*;
import javax.swing.border.LineBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.security.*;
import java.util.*;
public class LoginSystemBlockchain {

    // HashMap to store approved users and their passwords
    private static HashMap<String, String> userDb = new HashMap<>();

    // HashMap to store pending users and their passwords
    private static HashMap<String, String> pendingDb = new HashMap<>();

    public static void main(String[] args) {
        // Load users from file on startup
        loadFromFile();

        // Set Windows Look and Feel for the UI
        try {
            UIManager.setLookAndFeel("com.sun.java.swing.plaf.windows.WindowsLookAndFeel");
        } catch (Exception ex) {
            ex.printStackTrace();
        }

        // User Login Frame
        JFrame userFrame = createLoginFrame();

        // Admin Frame
        JFrame adminFrame = createAdminFrame(userFrame);

        // Display both frames
        userFrame.setVisible(true);
        adminFrame.setVisible(true);
    }

    private static JFrame createLoginFrame() {
        JFrame userFrame = new JFrame("User Login");
        userFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        userFrame.setSize(800, 800);
        userFrame.setLayout(new GridLayout(4, 2));

        JTextField userField = new JTextField();
        JPasswordField passField = new JPasswordField();
        JButton userLoginButton = new JButton("Login");
        JButton userSignUpButton = new JButton("Sign up");
        JLabel userStatusLabel = new JLabel("Enter login details");

        JPanel userPanel = new JPanel();
        userPanel.setBorder(new LineBorder(new Color(0, 0, 0)));
        userPanel.setBackground(new Color(204, 229, 255));
        userPanel.setLayout(new GridLayout(4, 2));

        userPanel.add(new JLabel("Username: "));
        userPanel.add(userField);
        userPanel.add(new JLabel("Password: "));
        userPanel.add(passField);
        userPanel.add(userLoginButton);
        userPanel.add(userSignUpButton);
        userPanel.add(userStatusLabel);
        userFrame.add(userPanel);

        // User login button action
        userLoginButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String user = userField.getText();
                String pass = hashPassword(new String(passField.getPassword()));

                if (userDb.get(user) != null && userDb.get(user).equals(pass)) {
                    userStatusLabel.setText("Login successful");
                } else if (pendingDb.get(user) != null && pendingDb.get(user).equals(pass)) {
                    userStatusLabel.setText("Your request is pending at admin");
                } else {
                    userStatusLabel.setText("Invalid login details");
                }
            }
        });

        // User signup button action
  
userSignUpButton.addActionListener(new ActionListener() {
    public void actionPerformed(ActionEvent e) {
        String user = userField.getText();
        String pass = hashPassword(new String(passField.getPassword()));

        // Check if username is already taken
        if (userDb.containsKey(user) || pendingDb.containsKey(user)) {
            userStatusLabel.setText("Username is already taken");
            return;
        }

        pendingDb.put(user, pass);
        saveToFile();
        userStatusLabel.setText("Signup successful, please wait for admin approval");
        // Add new block in blockchain for each new user
        writeToBlockchain(user, pass);
    }
});

        return userFrame;
    }

    private static JFrame createAdminFrame(JFrame userFrame) {
        JFrame adminFrame = new JFrame("Admin");
        adminFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        adminFrame.setSize(800, 800);

        JTextField adminUserField = new JTextField();
        JButton adminApproveButton = new JButton("Approve");
        JLabel adminStatusLabel = new JLabel("");

        String[] columnNames = {"Username", "Status"};
        DefaultTableModel model = new DefaultTableModel(columnNames, 0);
        JTable table = new JTable(model);
        refreshTable(model);

        JScrollPane scrollPane = new JScrollPane(table);
        table.setFillsViewportHeight(true);

        // Admin approve button action
        adminApproveButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String user = adminUserField.getText();

                if (pendingDb.get(user) != null) {
                    userDb.put(user, pendingDb.get(user));
                    pendingDb.remove(user);
                    adminStatusLabel.setText("User " + user + " approved");
                    saveToFile();
                } else {
                    adminStatusLabel.setText("User " + user + " not found");
                }
                refreshTable(model);
            }
        });

        adminFrame.setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridwidth = GridBagConstraints.REMAINDER;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        adminFrame.add(new JLabel("Username: "), gbc);
        adminFrame.add(adminUserField, gbc);
        adminFrame.add(adminApproveButton, gbc);
        adminFrame.add(adminStatusLabel, gbc);
        gbc.fill = GridBagConstraints.BOTH;
        gbc.weightx = 1;
        gbc.weighty = 1;
        adminFrame.add(scrollPane, gbc);

        return adminFrame;
    }

    // Utility function to hash a password
    private static String hashPassword(String password) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] hash = md.digest(password.getBytes(StandardCharsets.UTF_8));
            StringBuilder sb = new StringBuilder();

            for (byte b : hash) {
                sb.append(String.format("%02x", b));
            }

            return sb.toString();
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException(e);
        }
    }

    // Load users from the files
    private static void loadFromFile() {
        File userFile = new File("users.txt");
        File pendingFile = new File("pending.txt");

        try {
            Scanner userScanner = new Scanner(userFile);
            Scanner pendingScanner = new Scanner(pendingFile);

            while (userScanner.hasNext()) {
                String[] line = userScanner.nextLine().split(" ");
                userDb.put(line[0], line[1]);
            }

            while (pendingScanner.hasNext()) {
                String[] line = pendingScanner.nextLine().split(" ");
                pendingDb.put(line[0], line[1]);
            }

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }

    // Save users to the files
    private static void saveToFile() {
        File userFile = new File("users.txt");
        File pendingFile = new File("pending.txt");

        try {
            FileWriter userWriter = new FileWriter(userFile);
            FileWriter pendingWriter = new FileWriter(pendingFile);

            for (Map.Entry<String, String> entry : userDb.entrySet()) {
                userWriter.write(entry.getKey() + " " + entry.getValue() + "\n");
            }

            for (Map.Entry<String, String> entry : pendingDb.entrySet()) {
                pendingWriter.write(entry.getKey() + " " + entry.getValue() + "\n");
            }

            userWriter.close();
            pendingWriter.close();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // Refresh the admin table with latest users data
    private static void refreshTable(DefaultTableModel model) {
        model.setRowCount(0);
        for (Map.Entry<String, String> entry : userDb.entrySet()) {
            model.addRow(new Object[]{entry.getKey(), "Approved"});
        }
        for (Map.Entry<String, String> entry : pendingDb.entrySet()) {
            model.addRow(new Object[]{entry.getKey(), "Pending"});
        }
    }

    // Write user data to the blockchain.txt file
    private static void writeToBlockchain(String user, String pass) {
        try {
            FileWriter fw = new FileWriter("blockchain.txt", true);
            fw.write("###########\n");
            fw.write(user + "\n");
            fw.write(pass + "\n");
            fw.write("block#: " + UUID.randomUUID().toString().replace("-", "") + "\n");
            fw.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
